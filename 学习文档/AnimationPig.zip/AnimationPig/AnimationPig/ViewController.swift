//
//  ViewController.swift
//  AnimationPig
//
//  Created by apple on 16/2/1.
//  Copyright © 2016年 mountor_zj. All rights reserved.
//

import UIKit
/// 翻译的弹簧动画
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let cuteView = RYCuteView(frame: CGRectMake(0 , 0 ,320 ,568))
        cuteView.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(cuteView)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

