//
//  RYCuteView.swift
//  AnimationPig
//
//  Created by apple on 16/2/1.
//  Copyright © 2016年 mountor_zj. All rights reserved.
//

import UIKit

/// 屏幕宽度
let sysTem_width = UIScreen.mainScreen().bounds.width
/// 屏幕高度
let sysTem_Height = UIScreen.mainScreen().bounds.height
/// 图形最小高度
let min_Height: CGFloat = 100

var kX = "curveX"
var kY = "curveY"

class RYCuteView: UIView {
    var mHeight: CGFloat = 0
    var curveX: CGFloat = 0 /// r5点  x坐标
    var  curveY: CGFloat = 0 /// r5点 y坐标
     var curveView: UIView!
     var displayLink: CADisplayLink!
     var shapeLayer: CAShapeLayer!
    var isAnimating: Bool?

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addObserver(self, forKeyPath: kX, options: NSKeyValueObservingOptions.New, context: nil)
        self.addObserver(self, forKeyPath: kY, options: NSKeyValueObservingOptions.New, context: nil)
        self.configShapeLayer()
        self.configCurveView()
        self.configAction()
        
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func drawRect(rect: CGRect) {
        super.drawRect(rect)
    }
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        if keyPath == kX || keyPath == kY{
            self.updateShapeLayerPath()
        }
    }
    
    
    //MARK: -Configuration
    func configAction(){
        mHeight = 100           // 手势移动时相对高度
        isAnimating = false     // 是否处于动效状态
        
        let pan = UIPanGestureRecognizer(target: self, action: "handlePanAction:")
        self.userInteractionEnabled = true
        self.addGestureRecognizer(pan)
        // CADisplayLink默认每秒运行60次calculatePath是算出在运行期间_curveView的坐标，从而确定_shapeLayer的形状
        let _displayLink = CADisplayLink(target: self, selector: "calculatePath")
        displayLink = _displayLink
        displayLink.addToRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
        displayLink.paused = true
        
    }
    
    
    func configShapeLayer(){
        let _shapeLayer = CAShapeLayer()
        shapeLayer = _shapeLayer
        shapeLayer.fillColor = UIColor(red: 57 / 255, green: 67 / 255, blue: 89 / 255, alpha: 1).CGColor
        self.layer.addSublayer(shapeLayer)
    }
    
    
    func configCurveView(){
        // _curveView就是r5点
        self.curveX = sysTem_width / 2
        self.curveY = min_Height
        let _curVeView = UIView(frame: CGRectMake(curveX ,curveY ,3 ,3))
        curveView = _curVeView
        curveView.backgroundColor = UIColor.redColor()
        self.addSubview(curveView)
    }
    
    
    
    //MARK: - Action
    func handlePanAction(pan: UIPanGestureRecognizer){
        if isAnimating! {
            if pan.state == UIGestureRecognizerState.Changed{
                // 手势移动时，_shapeLayer跟着手势向下扩大区域
                let point: CGPoint = pan.translationInView(self)
                
                // 这部分代码使r5红点跟着手势走
                mHeight = point.y * CGFloat(0.7) + min_Height
                self.curveX = sysTem_width / 2 + point.x
                self.curveY = mHeight > min_Height ?  mHeight
                : min_Height
                curveView.frame = CGRectMake(curveX, curveY, curveView.frame.width, curveView.frame.height)
            }
            else if pan.state == UIGestureRecognizerState.Cancelled || pan.state == UIGestureRecognizerState.Ended || pan.state == UIGestureRecognizerState.Failed{
                // 手势结束时,_shapeLayer返回原状并产生弹簧动效
                isAnimating = true
                //开启displaylink,会执行方法calculatePath.
                displayLink.paused = false
                
                /// 弹簧特效
                UIView.animateWithDuration(1,
                    delay: 0,
                    usingSpringWithDamping: 0.5,
                    initialSpringVelocity: 0,
                    options: UIViewAnimationOptions.CurveEaseInOut,
                    animations: {
                         // 曲线点(r5点)是一个view.所以在block中有弹簧效果.然后根据他的动效路径,在calculatePath中计算弹性图形的形状
                            () -> Void in
                            self.curveView.frame = CGRectMake(sysTem_width / 2, min_Height, 3, 3)
                        
                    },
                    completion: { [weak self](finish) -> Void in
                        if finish{
                                self?.displayLink.paused = true
                                self?.isAnimating = false
                        }
                })
                
            }
        }
    }
    
    
    func updateShapeLayerPath(){
        // 更新_shapeLayer形状
        let tPath = UIBezierPath()
        tPath.moveToPoint(CGPointMake(0, 0))
        /// r1
        tPath.addLineToPoint(CGPointMake(sysTem_width, 0))
        /// r2
        tPath.addLineToPoint(CGPointMake(sysTem_width, min_Height))
        /// r4
        tPath.addQuadCurveToPoint(CGPointMake(0, min_Height), controlPoint: CGPointMake(curveX, curveY))
        tPath.closePath()
        shapeLayer.path = tPath.CGPath
        
    }
    
    func calculatePath(){
        // 由于手势结束时,r5执行了一个UIView的弹簧动画,把这个过程的坐标记录下来,并相应的画出_shapeLayer形状
        let layer = curveView.layer.presentationLayer() as?  CALayer
        self.curveX = layer!.position.x
        self.curveY = layer!.position.y
    }
    
}
